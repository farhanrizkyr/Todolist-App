<?php

namespace App\Http\Controllers\Login;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Hash;
class DaftarController extends Controller
{
     public function register()
   {
     return view('Login/register');
   }

   public function proses_register($value='')
   {
     request()->validate([
      'name'=>'required',
      'username'=>'required|unique:users',
      'email'=>'required|unique:users',
      'password'=>'required|confirmed',

     ]);
     User::create([
      'name'=>request()->name,
      'email'=>request()->email,
      'username'=>request()->username,
      'password'=>hash::make(request()->password),

     ]);
     return redirect('/login');
   }
}
