@extends('master_dash.tampil')
@section('title','Dashboard')
@section('content')


<div class="container">
	<div class="card mt-5 ">
  <div class="card-header bg-primary text-white lg-5">
 <i class="bi bi-list-ul"></i> Daftar Kegiatan
  </div>

@if(Session::get('buat'))
  <div class="alert alert-primary alert-dismissible fade show mt-5" role="alert">
  <strong>Berhasil!</strong> {{Session::get('buat')}}
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

@if(Session::get('hapus'))
  <div class="alert alert-success alert-dismissible fade show mt-5" role="alert">
  <strong>Berhasil!</strong> {{Session::get('hapus')}}
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

@if(Session::get('konfirmasi'))
  <div class="alert alert-info alert-dismissible fade show mt-5" role="alert">
  <strong>Berhasil!</strong> {{Session::get('konfirmasi')}}
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif


  <div class="card-body lg-5">
    <h5 class="card-title"><button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
  <i class="bi bi-plus-lg"></i> Buat Kegiatan
</button></h5>
  

  <div class="table-responsive">
    <table class="table table-hover mt-4">
  <thead>
    <tr>
    <th>No</th>
    <th>Kegiatan</th>
    <th>Tanggal Buat</th>
    <th>Status</th>
    <th>Aksi</th>
    
    </tr>
  </thead>
  <tbody>
   <?php  $nomor=1; ?>
    @forelse($todo as $lists)
    <tr>
      <td>{{$loop->iteration}}</td>
      <td>

          @if($lists->status=='Belum Dilakukan')
         {{$lists->name}}
        @endif
        @if($lists->status=='Sudah Dilakukan')
        <strong><s>{{$lists->name}}</s></strong>
        @endif
      </td>
      <td>{{\Carbon\Carbon::parse($lists->created_at)->isoformat('dddd D,MMMM Y')}}</td>
   <td>
         @if($lists->status=='Belum Dilakukan')
       <span class="badge text-bg-danger">
  
       {{$lists->status}}

       </span>

     
       @endif

         @if($lists->status=='Sudah Dilakukan')
       <span class="badge text-bg-primary">
  
       {{$lists->status}}

       </span>

     
       @endif
   </td>

   <td>
     @if($lists->status=='Belum Dilakukan')
      <form method="post" action="/home/konfirmasi/{{$lists->id}}" class="d-inline">
        @method('put')
        @csrf
        <button class="btn btn-primary btn-sm">Konfrmasi</button>
      </form>

         <form method="post" action="/home/destroy/{{$lists->id}}" class="d-inline">
          @csrf
          @method('delete')
        <button  onclick="return confirm('Yakin Ingin Menghapus?')" class="btn btn-danger btn-sm">Hapus</button>
      </form>

      <a href="#" class="btn btn-warning btn-sm"  data-bs-toggle="modal" data-bs-target="#ubah-kegiata{{$lists->id}}"> Edit</a>
     @endif

        @if($lists->status=='Sudah Dilakukan')

          <form method="post" action="/home/destroy/{{$lists->id}}" class="d-inline">
          @csrf
          @method('delete')
        <button onclick="return confirm('Yakin Ingin Menghapus?')"  class="btn btn-danger btn-sm">Hapus</button>
      </form>
     @endif
   </td>

   @empty
    <td colspan="5">
      <div class="alert alert-danger text-center" role="alert">
       Anda Belum Membuat List Kegiatan !!
</div>
    </td>
    @endforelse
    
  </tbody>
  </table>
  </div>



  @foreach($todo as $lists)
<div class="modal fade" id="ubah-kegiata{{$lists->id}}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title" id="exampleModalLabel">Ubah Kegiatan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <form method="post" action="/home/ubah-kegiatan/{{$lists->id}}">
         @csrf 
         <div class="grup">
        <label>Kegiatan</label>
        <input type="text" name="name" value="{{$lists->name}}" class="form-control @error('name')is-invalid @enderror">
        @error('name')
        <p class="text-danger">{{$message}}</p>
        @enderror
      </div>
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="bi bi-x-circle-fill"></i> Close</button>
        <button type="submit" class="btn btn-primary"><i class="bi bi-send"></i> Update </button>
      </div>
         </form>
    </div>
  </div>
</div>

  @endforeach
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Isi Kegiatan</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post" action="">
        @csrf
      <div class="modal-body">
      <div class="grup">
        <label>Kegiatan</label>
        <input type="text" name="name" class="form-control @error('name')is-invalid @enderror">
        @error('name')
        <p class="text-danger">{{$message}}</p>
        @enderror
      </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="bi bi-x-circle-fill"></i> Close</button>
        <button type="submit" class="btn btn-primary"><i class="bi bi-send"></i> Save </button>
      </div>
      </form>
    </div>
  </div>
</div>
  </div>
</div>
</div>
@endsection