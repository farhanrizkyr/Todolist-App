<nav class="navbar navbar-expand-lg bg-primary text-white">
  <div class="container-fluid ">
    <a class="navbar-brand text-white" href="/home">Todolist App</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mb-2 mb-lg-0 ms-auto ">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
       	<?php echo e(Auth::user()->name); ?>

          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Setting</a></li>
            <li><a class="dropdown-item" href="/login">Logout</a></li>
        
          </ul>
        </li>
       
      </ul>
     
    </div>
  </div>
</nav><?php /**PATH C:\laragon\www\Todolist\resources\views/master_dash/nav.blade.php ENDPATH**/ ?>