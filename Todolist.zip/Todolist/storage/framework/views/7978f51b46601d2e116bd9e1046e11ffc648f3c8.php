
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="card mt-5 ">
  <div class="card-header lg-5">
 Daftar Kegiatan
  </div>
  <div class="card-body lg-5">
    <h5 class="card-title"><button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
  <i class="bi bi-plus-lg"></i> Buat Kegiatan
</button></h5>
  <table class="table table-hover mt-4">
  <thead>
    <tr>
        <th>No</th>
    <th>Kegiatan</th>
    <th>Status</th>
    <th>Aksi</th>
    
    </tr>
  </thead>
  <tbody>
   <?php  $nomor=1; ?>
    <?php $__currentLoopData = $todo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($loop->iteration); ?></td>
      <td><?php echo e($lists->name); ?></td>
   <td>
         <?php if($lists->status=='Belum Dilakukan'): ?>
       <span class="badge text-bg-danger">
  
       <?php echo e($lists->status); ?>


       </span>

     
       <?php endif; ?>

         <?php if($lists->status=='Sudah Dilakukan'): ?>
       <span class="badge text-bg-primary">
  
       <?php echo e($lists->status); ?>


       </span>

     
       <?php endif; ?>
   </td>

   <td>
     <?php if($lists->status=='Belum Dilakukan'): ?>
      <form method="post" action="/home/konfirmasi/<?php echo e($lists->id); ?>" class="d-inline">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <button class="btn btn-primary btn-sm">Konfrmasi</button>
      </form>

         <form method="post" action="/home/destroy/<?php echo e($lists->id); ?>" class="d-inline">
          <?php echo csrf_field(); ?>
          <?php echo method_field('delete'); ?>
        <button  onclick="return confirm('Yakin Ingin Menghapus?')" class="btn btn-danger btn-sm">Hapus</button>
      </form>
     <?php endif; ?>

        <?php if($lists->status=='Sudah Dilakukan'): ?>

          <form method="post" action="/home/destroy/<?php echo e($lists->id); ?>" class="d-inline">
          <?php echo csrf_field(); ?>
          <?php echo method_field('delete'); ?>
        <button onclick="return confirm('Yakin Ingin Menghapus?')"  class="btn btn-danger btn-sm">Hapus</button>
      </form>
     <?php endif; ?>
   </td>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  </table>
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Isi Kegiatan</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post" action="">
        <?php echo csrf_field(); ?>
      <div class="modal-body">
      <div class="grup">
        <label>Kegiatan</label>
        <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="bi bi-x-circle-fill"></i> Close</button>
        <button type="submit" class="btn btn-primary"><i class="bi bi-send"></i> Save </button>
      </div>
      </form>
    </div>
  </div>
</div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master_dash.tampil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Todolist\resources\views/Dashboard/index.blade.php ENDPATH**/ ?>